x_a = 2;
y_a = 6 * x_a^3 + 4 / x_a

x_b = 9;
y_b = x_b / (4^3) + 3 * x_b 

x_c = 8;
y_c = (4 * x_c)^2 / 25

x_d = 3;
y_d = 2 - sin(x_d) / 5

x_e = 20;
y_e = 7 * x_e^(-1/3) + 4 * x_e^0.58